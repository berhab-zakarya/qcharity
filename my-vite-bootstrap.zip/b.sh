#!/bin/bash

# Create base directories
mkdir -p public/Content/QCGlobal/images/Opject
mkdir -p public/Content/QCGlobal/icons
mkdir -p public/Content/images/footer

# Function to download files with proper error handling
download_file() {
  local url=$1
  local destination=$2
  
  echo "Downloading: $url to $destination"
  
  # Create the directory if it doesn't exist
  mkdir -p "$(dirname "$destination")"
  
  # Try to download the file
  curl -s -L --create-dirs -o "$destination" "$url"
  
  # Check if download was successful
  if [ $? -eq 0 ]; then
    echo "Successfully downloaded: $destination"
  else
    echo "Failed to download: $url"
  fi
}

# Base URL for Qatar Charity content
base_url="https://www.qcharity.org"

# Download images from /Content/QCGlobal/images/
image_files=(
  "quotegrey.svg"
  "semicircleorange.svg"
  "534.jpg"
  "whoweareorangecircle.svg"
  "Where-1.jpg"
  "whoweareprimarycircle.svg"
  "wh3.png"
  "blackswigly.svg"
  "vision-pic.png"
  "Wher2.jpg"
  "Wher3.jpg.jpg"
  "mission.jpg"
  "iso9001.svg"
  "iso31000.svg"
  "iso27001.svg"
  "iso37301.svg"
  "iso18295.svg"
)

for file in "${image_files[@]}"; do
  download_file "$base_url/Content/QCGlobal/images/$file" "public/Content/QCGlobal/images/$file"
done

# Download images from /Content/QCGlobal/images/Opject/
opject_files=(
  "Group 8087.svg"
  "Group 8088.svg"
  "Group 8089.svg"
  "Group 8090.svg"
  "Group 8093.svg"
  "sahm-3.svg"
  "Group 8095.svg"
  "Group 8096.svg"
  "Group 8097.svg"
  "Group 8098.svg"
  "Group 8099.svg"
)

for file in "${opject_files[@]}"; do
  download_file "$base_url/Content/QCGlobal/images/Opject/$file" "public/Content/QCGlobal/images/Opject/$file"
done

# Download icons from /Content/QCGlobal/icons/
icon_files=(
  "qc-main-logo.svg"
  "START-NETWORK.png"
  "CHS-Alliance.png"
  "IOM.png"
  "btn-face-rounded.svg"
  "btn-twi-rounded.svg"
  "btn-insta-rounded.svg"
)

for file in "${icon_files[@]}"; do
  download_file "$base_url/Content/QCGlobal/icons/$file" "public/Content/QCGlobal/icons/$file"
done

# Download footer images
footer_files=(
  "play-store.svg"
  "app-store.svg"
)

for file in "${footer_files[@]}"; do
  download_file "$base_url/Content/images/footer/$file" "public/Content/images/footer/$file"
done

# Create the custom CSS file
echo "Creating custom CSS file..."
cat > public/Content/QCGlobal/css/custom-styles.css << 'EOL'
$(cat custom-styles.css)
EOL

echo "Asset download and organization complete!"
echo "Make sure to include the CSS file in your HTML: <link href='/Content/QCGlobal/css/custom-styles.css' rel='stylesheet' />"