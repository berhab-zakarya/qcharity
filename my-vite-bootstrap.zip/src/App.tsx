import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import LoginPage from './pages/Login'
import WhoAreWe from './pages/WhoWeArePage'
import SocialWelfare from './pages/Ourwork'

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/who-we-are" element={<WhoAreWe />} />
      <Route path="/ourwork" element={<SocialWelfare />} />
    </Routes>
  )
}

export default App