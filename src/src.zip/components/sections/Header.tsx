
const QatarCharityNavigation = () => {
  const hideNotificationBar = () => {
    // Implementation for hiding notification bar
    const notification = document.getElementById('covidNotification');
    if (notification) {
      notification.style.display = 'none';
    }
  };

  const toggleNotificationBar = () => {
    // Implementation for toggling notification bar
    const notification = document.getElementById('covidNotification');
    if (notification) {
      const currentDisplay = notification.style.display;
      notification.style.display = currentDisplay === 'none' ? 'block' : 'none';
    }
  };

  const changeCurrency = (currencyId:any) => {
    // Implementation for currency change
    console.log(`Currency changed to ID: ${currencyId}`);
    // You would implement actual currency change logic here
  };

  const subForm = () => {
    // Implementation for donate now button
    console.log('Donate Now clicked');
    // You would implement actual donation form submission here
  };

  return (
    <nav className="qcg-menu navbar navbar-light bg-white fixed-top border-bottom">
      <div id="covidNotification" className="container-fluid background-pink text-center" style={{ height: '50px' }}>
        <div className="col">
          <a className="fw-bold text-decoration-none text-body" href="/en/global/covidinternational">
            <span>COVID-19 RESPONSE</span>
          </a>
          <a href="/en/global/covidinternational" className="btn btn-orange rounded-pill px-2 py-2 ms-4 ms-sm-7">
            <small>More <span className="d-none d-md-inline">information</span></small>
          </a>
        </div>
        <a className="float-end" href="#" onClick={hideNotificationBar}>
          <img src="/content/QCGlobal/icons/close-button-notification.svg" alt="close" />
        </a>
      </div>

      <div className="container-fluid navbar-expand-xxl bg-white justify-content-start justify-content-lg-between px-0">
        <button id="navbar-toggler" 
          className="navbar-toggler shadow-none d-flex d-xxl-none align-items-center rounded-0"
          onClick={(e) => {
            e.currentTarget.classList.toggle('opened');
     
            toggleNotificationBar();
          }}
          type="button" 
          data-bs-toggle="collapse" 
          data-bs-target="#navbarNav" 
          aria-controls="navbarNav"
          aria-expanded="false" 
          aria-label="Toggle navigation">
          <svg className="mx-auto" width="32" height="32" viewBox="0 0 100 100">
            <path className="line line1" d="M 20,29.000046 H 80.000231 C 80.000231,29.000046 94.498839,28.817352 94.532987,66.711331 94.543142,77.980673 90.966081,81.670246 85.259173,81.668997 79.552261,81.667751 75.000211,74.999942 75.000211,74.999942 L 25.000021,25.000058" />
            <path className="line line2" cx="1" cy="1" r="1" d="M 20,50 H 80" />
            <path className="line line3" d="M 20,70.999954 H 80.000231 C 80.000231,70.999954 94.498839,71.182648 94.532987,33.288669 94.543142,22.019327 90.966081,18.329754 85.259173,18.331003 79.552261,18.332249 75.000211,25.000058 75.000211,25.000058 L 25.000021,74.999942" />
          </svg>
        </button>
        <div className="h-100 bg-light" style={{ width: '1px' }}></div>
        <a className="navbar-brand py-6 mb-0 h1 bg-white ms-0  ms-md-7" href="/en/global/q">
          <img src="/logo.svg" alt="" loading="lazy" className="mx-auto" />
        </a>
        <div className="collapse navbar-collapse bg-white" id="navbarNav">
          <form className="col-12 d-flex d-sm-none justify-content-end" style={{ height: '86px' }}>
            <button className="btn btn-lg btn-primary rounded-0 align-self-stretch px-5 f-base" onClick={subForm} type="button">
              Donate Now
            </button>
          </form>
     
        </div>
        
        {/* Right elements */}
        <ul className="navbar-nav navbar-nav-2 mb-0 fw-medium align-items-center flex-row ms-auto">
          {/* V-Divider */}
          <li className="nav-item h-100 bg-light d-none d-xl-block" style={{ width: '1px' }}></li>
          
          {/* Zakat */}
          <li className="nav-item d-none d-xl-block">
            <a className="nav-link" href="/en/global/zakat" aria-expanded="false">
              Zakat Calculator
            </a>
          </li>
          
          {/* V-Divider */}
          <li className="nav-item h-100 bg-light d-none d-md-block" style={{ width: '1px' }}></li>
          
          {/* Currency Dropdown */}
          <li className="nav-item dropdown d-none d-md-block">
            <a className="nav-link dropdown-toggle text-uppercase" aria-current="page" href="#"
              id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <span>USD</span>
            </a>
            <div className="dropdown-menu w-100" aria-labelledby="navbarDropdownMenuLink">
              <div className="container-fluid">
                <div className="row">
                  <div className="col-12 col-lg-11 offset-lg-1">
                    <div className="row h-100 d-flex flex-row">
                      <div className="col-4 align-self-center">
                        <h1 className="fw-normal" style={{ fontSize: '36px' }}>
                          Select
                        </h1>
                        <h1 className="display-4 fw-bolder">Currency</h1>
                      </div>
                      <ul className="col-3 list-group">
                        <li className="list-group-item">
                          <a className="dropdown-item" href="#" onClick={() => changeCurrency('1')}>QAR - Qatari riyal</a>
                        </li>
                        <li className="list-group-item">
                          <a className="dropdown-item" href="#" onClick={() => changeCurrency('2')}>USD - United States dollar</a>
                        </li>
                        <li className="list-group-item">
                          <a className="dropdown-item" href="#" onClick={() => changeCurrency('3')}>EUR - Euro</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </li>
          
          {/* V-Divider */}
          <li className="nav-item h-100 bg-light d-none d-md-block" style={{ width: '1px' }}></li>

          {/* Login - Desktop */}
          <li className="nav-item d-none d-md-flex">
            <a className="nav-link px-3" href="/en/global/account/login"> Login </a>
          </li>
          
          {/* Login - Mobile */}
          <li className="profilemenumobile nav-item d-flex d-md-none">
            <a href="/en/global/account/login"> Login </a>
          </li>

          <li className="nav-item" id="basketIconDiv"></li>
        </ul>
        
        {/* Donate Button */}
        <ul className="navbar-nav flex-row d-none d-sm-block ms-0">
          <li>
            <form className="d-flex text-nowrap" style={{ height: '86px' }}>
              <button className="btn btn-lg btn-primary rounded-0 align-self-stretch px-5 f-base"
                onClick={subForm} type="button">
                Donate Now
              </button>
            </form>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default QatarCharityNavigation;