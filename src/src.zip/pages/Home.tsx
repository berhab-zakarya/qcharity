
import CurrentAppeals from "../components/sections/CurrentAppeals";
import DevelopmentHumanitarianAid from "../components/sections/DevelopmentHumanitarianAid";
import Footer from "../components/sections/Footer";
import QatarCharityNavigation from "../components/sections/Header";
import ImpactStatistics from "../components/sections/ImpactStatistics";
import MainBanner from "../components/sections/MainBanner";
import NewsletterSubscription from "../components/sections/NewsLetterSubscribe";
import NewsSection from "../components/sections/NewsSection";
import OurAreasOfIntervention from "../components/sections/OurAreasOfIntervention";
import OurOffices from "../components/sections/OurOffices";
import PeopleReached from "../components/sections/PeopleReached";
import WhatDrivesUs from "../components/sections/WhatDrivesUs";
import OurPartners from "../components/sections/OurPartners";

export default function Home() {
  return (
    <div className="">
      {/* Header */}
      <QatarCharityNavigation />

      <main className="flex-1">
        <MainBanner />
        <WhatDrivesUs />

        <OurAreasOfIntervention />
        <ImpactStatistics />
        <PeopleReached />
        <DevelopmentHumanitarianAid />
        <OurPartners />
        <CurrentAppeals />
        <NewsSection />
        <OurOffices />
        <NewsletterSubscription />
      </main>

      <Footer/>
      {/* <Footer /> */}
    </div>
  );
}
